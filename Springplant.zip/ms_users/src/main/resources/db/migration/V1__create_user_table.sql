CREATE TABLE IF NOT EXISTS tbl_users (
    user_id BIGINT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50)    NOT NULL UNIQUE,
    email VARCHAR(150)      NOT NULL UNIQUE,
    password VARCHAR(255)   NOT NULL,
    role VARCHAR(20)        NOT NULL,
    address VARCHAR(255),
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);