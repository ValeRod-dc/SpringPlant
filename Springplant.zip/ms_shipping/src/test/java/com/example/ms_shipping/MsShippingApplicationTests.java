package com.example.ms_shipping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsShippingApplicationTests {

	@Test
	void contextLoads() {
	}

}
